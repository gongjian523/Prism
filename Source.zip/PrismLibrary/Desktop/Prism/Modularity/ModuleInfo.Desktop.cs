// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System;

namespace Microsoft.Practices.Prism.Modularity
{
    [Serializable]
    public partial class ModuleInfo
    {
    }
}
